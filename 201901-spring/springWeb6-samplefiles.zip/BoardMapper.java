package global.sesoc.web6.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.RowBounds;

import global.sesoc.web5.vo.Board;
import global.sesoc.web5.vo.Reply;

/**
 * 게시판 관련 Mybatis 사용 메서드
 */
public interface BoardMapper {
	//게시글 저장
	public int insertBoard(Board board);
	//글번호로 해당 게시글 검색
	public Board getBoard(int boardnum);


}
